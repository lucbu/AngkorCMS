<?php namespace -namespace-;

use Illuminate\Database\Eloquent\Model;

class -Object- extends Model {

	protected $table = '';

	public $timestamps = false;

	protected $fillable = ['module_id'];

}
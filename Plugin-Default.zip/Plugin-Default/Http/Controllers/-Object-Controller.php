<?php namespace -namespace-\Http\Controllers;

use Response;

class -Object-Controller extends -Object-BaseController {

	public function __construct() {
	}
}
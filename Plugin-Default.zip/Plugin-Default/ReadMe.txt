Definition :

	-Object- 	: Name of the main object
	-Plugin- 	: Name of the plugin (ex. AngkorCMSSlideshow)
	-pluginmin-	: Name of the plugin with little letters (ex. angkorcmsslideshows)
	-namespace-	: Namespace (ex. AngkorCMS\Slideshow
	-folderName-	: Name of the plugin's folder (ex. slideshow)
	-vendorName-	: Name of the vendor (ex. angkorcms)
	-showView-	: Name of the view to be shown

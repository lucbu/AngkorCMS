<?php

return array(

	/*
	 * Module's informations
	 */
	'showView' => '-vendorName-/-folderName-/-showView-',
	'unique' => true,
	'showDiv' => false,
);
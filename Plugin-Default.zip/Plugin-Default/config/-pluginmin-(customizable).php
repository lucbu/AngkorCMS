<?php

return array(

	/*
	 * Module's informations
	 */
	'namespace' => '-namespace-',
	'model' => '',
	'table' => '',
	'repository' => '-namespace-\Repositories\Eloquent\-Object-Repository',
	'route' => '-pluginmin-',
	'makerAjax' => '-pluginmin-.makerAjax',
	'makerView' => '-vendorName-/-folderName-/maker',
	'showView' => '-vendorName-/-folderName-/-showView-',
	'showDiv' => false,

	/*
	 * What middleware is needed to access this plugin
	 */
	'middleware' => [],

	/*
	 * What prefix will be used to the url accessing this plugin
	 */
	'prefix' => '',
);